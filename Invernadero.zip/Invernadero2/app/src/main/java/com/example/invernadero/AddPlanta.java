package com.example.invernadero;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.invernadero.clases.Planta;
import com.example.invernadero.controller.PlantaController;

import java.util.ArrayList;
import java.util.UUID;

public class AddPlanta extends AppCompatActivity {
    EditText addNombre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_planta);
        addNombre = findViewById(R.id.editTextNombre);


    }

    public void GuardarPlanta(View view){
        String nombre = String.valueOf(addNombre.getText());
        PlantaController.addPlanta(1253,nombre);

        finish();
        Intent irListado = new Intent(AddPlanta.this, ListadoPlanta.class);
        startActivity(irListado);
    }




    public void irOpciones(View v){
        finish();
        Intent irOpciones = new Intent(AddPlanta.this, Opciones.class);
        startActivity(irOpciones);
    }

}