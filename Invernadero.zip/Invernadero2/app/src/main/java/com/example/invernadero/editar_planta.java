package com.example.invernadero;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.invernadero.clases.Planta;
import com.example.invernadero.controller.PlantaController;

import java.util.ArrayList;

public class editar_planta extends AppCompatActivity {
    int idPlanta;
    String nombre;
    EditText EditNombre;
    Planta p;
    ArrayList<Planta> lst;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_planta);
        lst = PlantaController.findAll();

        EditNombre = findViewById(R.id.txtNomPlanta2);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null){
            nombre = bundle.getString("nombre");
            idPlanta = bundle.getInt("id");

            EditNombre.setText(nombre);
            p = lst.get(idPlanta);

        }

    }

    public void GuardarNombre(View view) {

        String nuevoNombre = String.valueOf(EditNombre.getText());
        PlantaController.findPlanta(p.getId()).setNombre(nuevoNombre);

        finish();
        Intent irListado = new Intent(editar_planta.this, ListadoPlanta.class);
        startActivity(irListado);
    }

    public void IrListado(View v){
        finish();
        Intent irListado = new Intent(editar_planta.this, ListadoPlanta.class);
        startActivity(irListado);
    }

}