package com.example.invernadero.clases;

public class Planta {
    public int id;
    public String nombre;
    public String humedad;
    public String temperatura;
    public String iluminacion;

    public Planta(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.humedad = "60%";
        this.temperatura = "22°C";
        this.iluminacion = "Buena Iluminación";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getHumedad() {
        return humedad;
    }

    public void setHumedad(String humedad) {
        this.humedad = humedad;
    }

    public String getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(String temperatura) {
        this.temperatura = temperatura;
    }

    public String getIluminacion() {
        return iluminacion;
    }

    public void setIluminacion(String iluminacion) {
        this.iluminacion = iluminacion;
    }
}