package com.example.invernadero;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.invernadero.clases.Planta;
import com.example.invernadero.controller.PlantaController;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddPlanta extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    EditText etNombre, etHum, etTemp, etIlum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_planta);

        etId = findViewById(R.id.etId)
        etNombre = findViewById(R.id.etNombre);
        etHum = findViewById(R.id.etHum);
        etTemp = findViewById(R.id.etTemp);
        etIlum = findViewById(R.id.etIlum);


        iniciarFireBase();

    }

    public void iniciarFireBase(){
        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }


    public void GuardarPlanta(View view){
        String id =
        String nom = etNombre.getText().toString();
        String temp = etTemp.getText().toString();
        String hum = etHum.getText().toString();
        String ilum = etIlum.getText().toString();

        Planta p = PlantaController.addPlanta(id ,nom, temp, hum, ilum);

    }

    ///String nombre = String.valueOf(etNombre.getText());
    ///    PlantaController.addPlanta(1253,nombre);

    ///finish();
    ///Intent irListado = new Intent(AddPlanta.this, ListadoPlanta.class);
    ///startActivity(irListado);


    public void irOpciones(View v){
        finish();
        Intent irOpciones = new Intent(AddPlanta.this, Opciones.class);
        startActivity(irOpciones);
    }

}