package com.example.invernadero;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
    }

    public void IrOpciones(View v) {
        finish();
        Intent iopciones = new Intent(Login.this, Opciones.class);
        startActivity(iopciones);
    }

    public void IraMain(View v){
        finish();
        Intent irMain = new Intent(Login.this, MainActivity.class);
        startActivity(irMain);
    }
}
