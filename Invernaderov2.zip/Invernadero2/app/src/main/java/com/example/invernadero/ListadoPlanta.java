package com.example.invernadero;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.invernadero.adapter.PlantaAdapter;
import com.example.invernadero.clases.Planta;
import com.example.invernadero.controller.PlantaController;

import java.util.ArrayList;
import java.util.List;

public class ListadoPlanta extends AppCompatActivity {

    ListView ListViewPlanta;
    Planta p;
    ArrayList<Planta> lst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listadoplanta);
        lst = PlantaController.findAll();
        ListViewPlanta=findViewById(R.id.listaPlanta);


        PlantaAdapter adapter=new PlantaAdapter(this, PlantaController.findAll());
        ListViewPlanta.setAdapter(adapter);

        ListViewPlanta.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                p = lst.get(i);
                Intent findPlanta = new Intent(ListadoPlanta.this, FindPlanta.class);

                findPlanta.putExtra("id",i);
                findPlanta.putExtra("nombre",p.getNombre());
                findPlanta.putExtra("humedad",p.getHumedad());
                findPlanta.putExtra("temperatura",p.getTemperatura());
                findPlanta.putExtra("iluminacion",p.getIluminacion());


                startActivity(findPlanta);
            }
        });
    }

    //Botones
    public void irOpciones(View v){
        finish();
        Intent irOpciones = new Intent(ListadoPlanta.this, Opciones.class);
        startActivity(irOpciones);
    }


}
